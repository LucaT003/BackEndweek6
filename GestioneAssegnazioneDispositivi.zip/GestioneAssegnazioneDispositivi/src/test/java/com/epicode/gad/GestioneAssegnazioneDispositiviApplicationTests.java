package com.epicode.gad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestioneAssegnazioneDispositiviApplicationTests {

	@Test
	void contextLoads() {
	}

}
