package com.epicode.gad.dispositivo;

public enum TipoDispositivo {

	SMARTPHONE, TABLET, LAPTOP
}
