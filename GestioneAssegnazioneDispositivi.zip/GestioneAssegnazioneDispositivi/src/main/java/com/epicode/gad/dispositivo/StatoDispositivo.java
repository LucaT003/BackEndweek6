package com.epicode.gad.dispositivo;

public enum StatoDispositivo {

	DISPONOBILE, ASSEGNATO, IN_MANUTENZIONE, DISMESSO
}
